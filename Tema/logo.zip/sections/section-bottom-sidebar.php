<section class="bottom-sidebar mb-5">
		<div class="container">
			<div class="row">
				<?php dynamic_sidebar('sidebar-bottom'); ?>
			</div>
		</div>
	</section>