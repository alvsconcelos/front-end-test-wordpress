<section class="store-map mb-5">
    <div class="map-container">
        <div id="map"></div>
        <div class="container finder-container">
            <div class="row d-flex justify-content-center">
                <div class="col-md-6 py-3 location-finder-wrapper">
                    <div class="row">
                        <div class="col-md-5 d-flex align-items-center">
                            <a href="#" class="btn btn-white btn-block btn-icon btn-auto-location"><i class="location"></i><span>Achar minha localização automaticamente</span></a>
                        </div>
                        <div class="col-md-1 p-0 d-flex align-items-center justify-content-center">
                            <span class="or">OU</span>
                        </div>
                        <div class="col-md-6 d-flex align-items-center">
                            <div class="inline-form">
                                <div class="input-row">
                                    <label for="#map-location-input">Digite o cep de onde você está</label>
                                    <input type="tel" id="map-location-input" placeholder="CEP">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a href="#" class="btn btn-white btn-search">Procurar</a>
    </div>
</section>