<?php
$args = array(
    'post_type'              => array('slide'),
	'order'                  => 'ASC',
    'nopaging'               => true,
);
$slides_query = new WP_Query($args);
query_featured_items();

if ($slides_query->have_posts()) { ?>
    <section class="slider">
        <div id="section-slider" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <?php
                    foreach (range(0, ($slides_query->post_count - 1)) as $num) {
                        printf('<li data-target="#section-slider" data-slide-to="%d" %s></li>', $num, $num == 0 ? 'class="active"' : '');
                    }
                ?>
            </ol>
            <div class="carousel-inner">
                <?php while ($slides_query->have_posts()) { ?>
                    <?php $slides_query->the_post(); ?>
                    <?php $slide_action = get_post_meta(get_the_ID(), '_logo_url', true); ?>
                    <div class="carousel-item<?php if ($slides_query->current_post == 0) echo ' active'; ?>">
                        <?php if ($slide_action) printf('<a href="%s">', $slide_action); ?>
                        <?php the_post_thumbnail('slider', ['class' => "d-block w-100 img-fluid"]); ?>
                        <?php if ($slide_action) printf('</a>'); ?>
                    </div>
                <?php } ?>
            </div>
            <a class="carousel-control-prev" href="#section-slider" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Anterior</span>
            </a>
            <a class="carousel-control-next" href="#section-slider" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Próximo</span>
            </a>
        </div>
    </section>
<?php } ?>

<?php wp_reset_postdata(); ?>