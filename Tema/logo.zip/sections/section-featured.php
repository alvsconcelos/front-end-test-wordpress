<?php
$items = query_featured_items();
?>

<?php if (count($items)) : ?>
    <section class="featured my-5">
        <div class="container">
            <div class="row">
                <?php
                    foreach ($items as $index => $item) :
                        if ($index == 0) {
                            $render = render_featured_item($item, true);
                            echo "<div class='col-md-4 mb-3'>$render</div><div class='col-md-8'><div class='row'>";
                        } else {
                            $render = render_featured_item($item);
                            $altclass = $index % 2 == 0 ? 'pl-sm-2' : 'pr-sm-2';
                            echo "<div class='col-md-6 mb-3 p-sm-0 $altclass'>$render</div>";
                        }
                    endforeach;
                    ?>
            </div>
        </div>
        </div>
        </div>
    </section>
<?php endif; ?>