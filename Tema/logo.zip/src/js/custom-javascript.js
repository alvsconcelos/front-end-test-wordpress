(function ($) {
    $(document).ready(function () {

        // Navbar 

        const mobile_navbar_toggler = $('#open-mobile-menu');
        const navbar_backdrop = $('#backdrop');

        mobile_navbar_toggler.on('click', (e) => {
            e.preventDefault();
            $('body').addClass('navbar-open');
        })

        navbar_backdrop.on('click', (e) => {
            e.preventDefault();
            $('body').removeClass('navbar-open');
        })


        // Maps

        const map_section_wrapper = $('section.store-map');
        const auto_locate_btn = $('.btn-auto-location', map_section_wrapper);
        const map_search_btn = $('.btn-search', map_section_wrapper);
        const map_location_input = $('#map-location-input');
        const autocomplete = new google.maps.places.Autocomplete(map_location_input[0], { componentRestrictions: { country: "br" } });
        const infowindow = new google.maps.InfoWindow({ content: '' });

        const map = new google.maps.Map(
            document.getElementById('map'), {
            zoom: 4,
            center: { lat: -14.235004, lng: -51.92528 },
            mapTypeControl: false,
            rotateControl: false,
            fullscreenControl: false,
            styles: [{ "elementType": "geometry", "stylers": [{ "color": "#f5f5f5" }] }, { "elementType": "labels.icon", "stylers": [{ "visibility": "off" }] }, { "elementType": "labels.text.fill", "stylers": [{ "color": "#f49e9e" }] }, { "elementType": "labels.text.stroke", "stylers": [{ "color": "#ffffff" }] }, { "featureType": "administrative.land_parcel", "elementType": "labels.text.fill", "stylers": [{ "color": "#bdbdbd" }] }, { "featureType": "poi", "elementType": "geometry", "stylers": [{ "color": "#f4f4f4" }] }, { "featureType": "poi", "elementType": "labels.text.fill", "stylers": [{ "color": "#757575" }] }, { "featureType": "poi.park", "elementType": "geometry", "stylers": [{ "color": "#e5e5e5" }] }, { "featureType": "poi.park", "elementType": "labels.text.fill", "stylers": [{ "color": "#9e9e9e" }] }, { "featureType": "road", "elementType": "geometry", "stylers": [{ "color": "#ffffff" }] }, { "featureType": "road.arterial", "elementType": "labels.text.fill", "stylers": [{ "color": "#757575" }] }, { "featureType": "road.highway", "elementType": "geometry", "stylers": [{ "color": "#dadada" }] }, { "featureType": "road.highway", "elementType": "labels.text.fill", "stylers": [{ "color": "#616161" }] }, { "featureType": "road.local", "elementType": "labels.text.fill", "stylers": [{ "color": "#9e9e9e" }] }, { "featureType": "transit.line", "elementType": "geometry", "stylers": [{ "color": "#f4f4f4" }] }, { "featureType": "transit.station", "elementType": "geometry", "stylers": [{ "color": "#f4f4f4" }] }, { "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#c9c9c9" }] }, { "featureType": "water", "elementType": "geometry.fill", "stylers": [{ "color": "#f4deda" }] }, { "featureType": "water", "elementType": "labels.text.fill", "stylers": [{ "color": "#9e9e9e" }] }]
        });

        if (maps_data.length) {
            maps_data.forEach(item => {
                var marker = new google.maps.Marker({
                    position: item,
                    map: map,
                    title: item.title
                })

                var infowindow = new google.maps.InfoWindow({ content: `<span><strong>${item.title}</strong></span>` });

                marker.addListener("click", () => {
                    infowindow.open(map, marker);
                });
            });
        }

        autocomplete.addListener("place_changed", () => {
            const place = autocomplete.getPlace();
            set_map_position(map, place.geometry.location)
        });

        map_search_btn.on('click', (e) => {
            e.preventDefault()
            map_section_wrapper.removeClass('results-show')
            map_location_input.focus()
        })

        auto_locate_btn.on('click', (e) => {
            e.preventDefault();
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition((position) => {
                    set_map_position(map, { lat: position.coords.latitude, lng: position.coords.longitude })
                });
            }
        })

        function set_map_position(map, pos) {
            map_section_wrapper.addClass('results-show');
            map.setCenter(pos);
            map.setZoom(17);
        }

        // Isso desativa o clique nos botões e envio de formulários.
        
        // $('a, button').on('click', (e) => {e.preventDefault()})
    });

})(jQuery);
