<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package logo
 */

?>

<div class="wrapper bg-primary py-5" id="wrapper-footer">

	<div class="container">
		<div class="row mb-4">
			<div class="col-md-12 col-xl-10">
				<div class="row">
					<?php dynamic_sidebar('sidebar-footer'); ?>
				</div>
			</div>
		</div>

		<?php
		$footer_credits = get_theme_mod('_logo_footer_credits', '');
		if (!empty($footer_credits)) :
			?>
			<div class="row">
				<div class="col-md-12">
					<footer class="site-footer" id="colophon">
						<div class="site-info">
							<?php printf('<p class="text-white m-0"><span class="year">%s</span>, %s</p>', date('Y'), $footer_credits); ?>
						</div>
					</footer>
				</div>
			</div>
		<?php endif; ?>
	</div>

</div>

</div>

<?php wp_footer(); ?>

</body>

</html>