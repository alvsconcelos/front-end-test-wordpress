<?php

/**
 * logo Theme Customizer
 *
 * @package logo
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function logo_customize_register($wp_customize)
{
	$wp_customize->get_setting('blogname')->transport         = 'postMessage';
	$wp_customize->get_setting('blogdescription')->transport  = 'postMessage';
	$wp_customize->get_setting('header_textcolor')->transport = 'postMessage';

	if (isset($wp_customize->selective_refresh)) {
		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '.site-title a',
				'render_callback' => 'logo_customize_partial_blogname',
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '.site-description',
				'render_callback' => 'logo_customize_partial_blogdescription',
			)
		);
	}
}
add_action('customize_register', 'logo_customize_register');

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function logo_customize_partial_blogname()
{
	bloginfo('name');
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function logo_customize_partial_blogdescription()
{
	bloginfo('description');
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function logo_customize_preview_js()
{
	wp_enqueue_script('logo-customizer', get_template_directory_uri() . '/js/customizer.js', array('customize-preview'), _S_VERSION, true);
}
add_action('customize_preview_init', 'logo_customize_preview_js');

function theme_options_customize_register($wp_customize)
{

	$prefix = "_logo_";

	// Create our panels

	$wp_customize->add_panel('theme_opt_panel', array(
		'title'          => __('Configurações do tema', 'logo'),
	));

	$wp_customize->add_section('info', array(
		'title'             => __('Informações', 'logo'),
		'panel'             => 'theme_opt_panel',
	));

	$wp_customize->add_setting($prefix . 'facebook', array(
		'type'          => 'theme_mod',
		'transport'     => 'refresh',
	));
	$wp_customize->add_control('facebook_control', array(
		'label'      => __('URL do Facebook', 'logo'),
		'section'    => 'info',
		'settings'   => $prefix . 'facebook',
		'type'       => 'text',
	));

	$wp_customize->add_setting($prefix . 'youtube', array(
		'type'          => 'theme_mod',
		'transport'     => 'refresh',
	));
	$wp_customize->add_control('youtube_control', array(
		'label'      => __('URL do Youtube', 'logo'),
		'section'    => 'info',
		'settings'   => $prefix . 'youtube',
		'type'       => 'text',
	));

	$wp_customize->add_setting($prefix . 'instagram', array(
		'type'          => 'theme_mod',
		'transport'     => 'refresh',
	));
	$wp_customize->add_control('instagram_control', array(
		'label'      => __('URL do Instagram', 'logo'),
		'section'    => 'info',
		'settings'   => $prefix . 'instagram',
		'type'       => 'text',
	));

	$wp_customize->add_setting($prefix . 'footer_credits', array(
		'type'          => 'theme_mod',
		'transport'     => 'refresh',
	));
	$wp_customize->add_control('footer_credits', array(
		'label'      => __('Texto do rodapé', 'logo'),
		'section'    => 'info',
		'settings'   => $prefix . 'footer_credits',
		'type'       => 'text',
	));
}

add_action('customize_register', 'theme_options_customize_register');
