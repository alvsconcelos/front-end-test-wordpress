<?php

/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package logo
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function logo_body_classes($classes)
{
	// Adds a class of hfeed to non-singular pages.
	if (!is_singular()) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if (!is_active_sidebar('sidebar-1')) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter('body_class', 'logo_body_classes');

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function logo_pingback_header()
{
	if (is_singular() && pings_open()) {
		printf('<link rel="pingback" href="%s">', esc_url(get_bloginfo('pingback_url')));
	}
}
add_action('wp_head', 'logo_pingback_header');

add_filter('wp_nav_menu_items', 'add_search_box_on_mobile_menu', 10, 2);

function add_search_box_on_mobile_menu($items, $args)
{
	if ($args->theme_location == 'topbar_menu') {
		$items .= sprintf('<li class="search-box"><form method="post"><input type="text" placeholder="Busca"><button class="btn" type="submit"><i class="search"></i></button></form></li>');
	}
	return $items;
}

// Dequeue Wordpress Emojis

remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_styles', 'print_emoji_styles');
