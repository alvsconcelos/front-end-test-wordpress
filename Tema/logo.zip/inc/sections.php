<?php

/**
 * Sections related functions
 *
 * @package logo
 */

/**
 * Slides
 */

if (!function_exists('create_slides_post_type')) {
    function create_slides_post_type()
    {

        $labels = array(
            'name'                  => _x('Slides', 'Post Type General Name', 'logo'),
            'singular_name'         => _x('Slide', 'Post Type Singular Name', 'logo'),
            'menu_name'             => __('Slides', 'logo'),
            'name_admin_bar'        => __('Slides', 'logo'),
            'all_items'             => __('Todos os slides', 'logo'),
            'add_new_item'          => __('Adicionar novo slide', 'logo'),
            'add_new'               => __('Adicionar novo', 'logo'),
            'new_item'              => __('Novo slide', 'logo'),
            'edit_item'             => __('Editar slide', 'logo'),
            'update_item'           => __('Atualizar slide', 'logo'),
        );
        $args = array(
            'label'                 => __('Slide', 'logo'),
            'description'           => __('Slides.', 'logo'),
            'labels'                => $labels,
            'supports'              => array('title', 'thumbnail'),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_position'         => 5,
            'menu_icon'             => 'dashicons-images-alt',
            'show_in_admin_bar'     => false,
            'show_in_nav_menus'     => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'rewrite'               => false,
            'capability_type'       => 'page',
        );
        register_post_type('slide', $args);
    }
    add_action('init', 'create_slides_post_type', 0);
}

if (!function_exists('create_slide_metabox')) {
    function create_slide_metabox()
    {

        $prefix = '_logo_';

        $cmb = new_cmb2_box(array(
            'id'           => $prefix . 'slide_data',
            'title'        => __('Dados do slide', 'logo'),
            'object_types' => array('slide'),
            'context'      => 'normal',
            'priority'     => 'default',
        ));

        $cmb->add_field(array(
            'name' => __('Link', 'logo'),
            'id' => $prefix . 'url',
            'type' => 'text_url',
            'desc' => __('Deixe vazio para desativar o clique.', 'logo'),
        ));
    }
    add_action('cmb2_init', 'create_slide_metabox');
}

/**
 * Featured
 */

if (!function_exists('create_featured_post_type')) {

    function create_featured_post_type()
    {

        $labels = array(
            'name'                  => _x('Destaques', 'Post Type General Name', 'logo'),
            'singular_name'         => _x('Destaque', 'Post Type Singular Name', 'logo'),
            'menu_name'             => __('Destaques', 'logo'),
            'name_admin_bar'        => __('Destaques', 'logo'),
            'all_items'             => __('Todos os destaques', 'logo'),
            'add_new_item'          => __('Adicionar novo destaque', 'logo'),
            'new_item'              => __('Novo destaque', 'logo'),
            'edit_item'             => __('Editar destaque', 'logo'),
            'update_item'           => __('Atualizar destaque', 'logo'),
        );
        $args = array(
            'label'                 => __('Destaque', 'logo'),
            'description'           => __('Destaques.', 'logo'),
            'labels'                => $labels,
            'supports'              => array('title', 'thumbnail'),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_position'         => 5,
            'menu_icon'             => 'dashicons-welcome-view-site',
            'show_in_admin_bar'     => false,
            'show_in_nav_menus'     => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'rewrite'               => false,
            'capability_type'       => 'page',
        );
        register_post_type('featured', $args);
    }
    add_action('init', 'create_featured_post_type', 0);
}

if (!function_exists('create_featured_metabox')) {
    function create_featured_metabox()
    {

        $prefix = '_logo_';

        $cmb = new_cmb2_box(array(
            'id'           => $prefix . 'featured_data',
            'title'        => __('Dados do destaque', 'logo'),
            'object_types' => array('featured'),
            'context'      => 'normal',
            'priority'     => 'default',
        ));

        $cmb->add_field(array(
            'name' => __('Texto acima do título', 'logo'),
            'id' => $prefix . 'above_title_text',
            'type' => 'text',
        ));

        $cmb->add_field(array(
            'name' => __('Conteúdo', 'logo'),
            'id' => $prefix . 'content',
            'type' => 'textarea',
        ));

        $cmb->add_field(array(
            'name' => __('Texto do botão', 'logo'),
            'id' => $prefix . 'button_text',
            'type' => 'text',
        ));

        $cmb->add_field(array(
            'name' => __('Link do botão', 'logo'),
            'id' => $prefix . 'button_url',
            'type' => 'text_url',
            'desc' => __('Deixe vazio para desativar o clique.', 'logo'),
        ));

        $cmb->add_field(array(
            'name' => __('Posição do conteúdo', 'logo'),
            'id' => $prefix . 'content_position',
            'type' => 'select',
            'options' => array(
                'tc' => __('Centro - Topo', 'logo'),
                'tb' => __('Centro - Fundo', 'logo'),
                'tl' => __('Centro - Esquerda', 'logo'),
                'tr' => __('Centro - Direita', 'logo'),
                'cl' => __('Canto - Esquerda Topo', 'logo'),
                'cr' => __('Canto - Direita Topo', 'logo'),
            ),
        ));

        $cmb->add_field(array(
            'name' => __('Item em destaque', 'logo'),
            'id' => $prefix . 'is_featured',
            'type' => 'radio_inline',
            'default' => '0',
            'options' => array(
                '1' => __('Sim', 'logo'),
                '0' => __('Não', 'logo'),
            ),
        ));
    }
    add_action('cmb2_init', 'create_featured_metabox');
}

if (!function_exists('query_featured_items')) {
    function query_featured_items()
    {
        $args = array(
            'post_type'              => array('featured'),
            'nopaging'               => true,
            'order'                  => 'ASC',
        );

        $featured_query = get_posts($args);
        $featured_items = array();

        if (count($featured_query)) {
            foreach ($featured_query as $item) {
                $featured_item['title'] = $item->post_title;
                $featured_item['above_title'] = get_post_meta($item->ID, '_logo_above_title_text', true);
                $featured_item['img'] = get_the_post_thumbnail($item->ID, 'featured', ['class' => 'img-fluid d-block w-100']);
                $featured_item['featured_img'] = get_the_post_thumbnail_url($item->ID, 'featured_large', ['class' => 'img-fluid d-block w-100']);
                $featured_item['content'] = get_post_meta($item->ID, '_logo_content', true);
                $featured_item['button_text'] = get_post_meta($item->ID, '_logo_button_text', true);
                $featured_item['button_url'] = get_post_meta($item->ID, '_logo_button_url', true);
                $featured_item['position'] = get_post_meta($item->ID, '_logo_content_position', true);

                // If is a top-featured item, it will be at top of array
                if (get_post_meta($item->ID, '_logo_is_featured', true)) {
                    array_unshift($featured_items, $featured_item);
                } else {
                    $featured_items[] = $featured_item;
                }
            }
        }

        wp_reset_postdata();

        return $featured_items;
    }
}

if (!function_exists('render_featured_item')) {
    function render_featured_item($item, $large = false)
    {
        if ($large) {
            return sprintf('<div class="item large" style="background:url(%s)"><div class="btn-wrapper"><a href="%s" class="btn btn-block btn-featured">%s</a></div></div>', $item['featured_img'], $item['button_url'], $item['button_text']);
        } else {
            return sprintf('<div class="item">%s<div class="content-wrapper %s"><div><span class="ab-tt">%s</span><h5 class="title">%s</h5><p class="content">%s</p><a href="%s" class="btn-white">%s</a></div></div></div>', $item['img'], $item['position'], $item['above_title'], $item['title'], $item['content'], $item['button_url'], $item['button_text']);
        }
    }
}


/**
 * Stores
 */

if (!function_exists('create_stores_post_type')) {

    function create_stores_post_type()
    {

        $labels = array(
            'name'                  => _x('Lojas', 'Post Type General Name', 'logo'),
            'singular_name'         => _x('Loja', 'Post Type Singular Name', 'logo'),
            'menu_name'             => __('Lojas', 'logo'),
            'name_admin_bar'        => __('Lojas', 'logo'),
            'all_items'             => __('Todas as lojas', 'logo'),
            'add_new_item'          => __('Adicionar nova loja', 'logo'),
            'add_new'               => __('Adicionar novo', 'logo'),
            'new_item'              => __('Nova loja', 'logo'),
            'edit_item'             => __('Editar loja', 'logo'),
            'update_item'           => __('Atualizar loja', 'logo'),
        );
        $args = array(
            'label'                 => __('Loja', 'logo'),
            'description'           => __('Lojas.', 'logo'),
            'labels'                => $labels,
            'supports'              => array('title'),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_position'         => 5,
            'menu_icon'             => 'dashicons-store',
            'show_in_admin_bar'     => false,
            'show_in_nav_menus'     => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'rewrite'               => false,
            'capability_type'       => 'page',
        );
        register_post_type('store', $args);
    }
    add_action('init', 'create_stores_post_type', 0);
}

if (!function_exists('create_stores_metabox')) {

    function create_stores_metabox()
    {

        $prefix = '_logo_';

        $cmb = new_cmb2_box(array(
            'id'           => $prefix . 'store_meta',
            'title'        => __('Dados da loja', 'logo'),
            'object_types' => array('store'),
            'context'      => 'normal',
            'priority'     => 'default',
        ));

        $cmb->add_field(array(
            'name' => __('Latitude', 'logo'),
            'id' => $prefix . 'latitude',
            'type' => 'text',
        ));

        $cmb->add_field(array(
            'name' => __('Longitude', 'logo'),
            'id' => $prefix . 'longitude',
            'type' => 'text',
        ));
    }

    add_action('cmb2_init', 'create_stores_metabox');
}

if (!function_exists('get_stores')) {
    function get_stores()
    {
        $args = array(
            'post_type'              => array('store'),
            'nopaging'               => true,
            'order'                  => 'ASC',
        );

        $store_query = get_posts($args);
        $stores = array();

        if (count($store_query)) {
            foreach ($store_query as $item) {
                $store['title'] = $item->post_title;
                $store['lat'] = floatval(get_post_meta($item->ID, '_logo_latitude', true));
                $store['lng'] = floatval(get_post_meta($item->ID, '_logo_longitude', true));

                $stores[] = $store;
            }
        }

        return $stores;
    }
}
